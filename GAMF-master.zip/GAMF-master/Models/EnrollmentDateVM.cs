﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GAMF.Models
{
    public class EnrollmentDateVM
    {
        public DateTime EnrollmentDate { get; set; }
        public int StudentCount { get; set; }
        
    }
}
