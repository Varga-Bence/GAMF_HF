﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;*/
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GAMF.Models
{
    public class StudentCredit
    {
        public int StudentName { get; set; }
        public int Credits { get; set; }
    }
}
