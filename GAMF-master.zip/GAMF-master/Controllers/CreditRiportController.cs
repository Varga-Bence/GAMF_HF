﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GAMF.Data;
using GAMF.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace GAMF.Controllers
{
    public class CreditRiportController : Controller
    {

        private readonly GAMFDbContext _context;

        public CreditRiportController(GAMFDbContext context)
        {
            _context = context;
        }
        public IActionResult CreditRiport()
        {
            List<StudentCredit> studentCreditList;
            IQueryable<StudentCredit> data =
                from enrollment in _context.Enrollments
                join student in _context.Students on enrollment.StudentId equals student.Id
                join course in _context.Courses on enrollment.CourseId equals course.CourseId
                where enrollment.Grade != Grade.F
                group enrollment by enrollment.StudentId into studentCredits
                select new StudentCredit()
                {
                    StudentName = studentCredits.Key,
                    Credits = 5
                    //StudentName = _context.Students.,
                    //Credits = studentCredits.Sum();
                };
            //studentCreditList.Add(new StudentCredit())

            studentCreditList = data.ToList();

            return View(studentCreditList);
        }
    }
}
